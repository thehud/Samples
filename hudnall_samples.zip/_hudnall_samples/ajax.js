// Sample AJAX file by James Hudnall james.hudnall@gmail.com
       var path = window.location.origin;
        var url = path + "/ajax.php";
        var modal = (function(){
				var 
				method = {},
				$overlay,
				$modal,
				$bar,
				$close;

				// Center the modal in the viewport
				method.center = function () {
					var top, left;

					top = Math.max($(window).height() - $modal.outerHeight(), 0) / 2;
					left = Math.max($(window).width() - $modal.outerWidth(), 0) / 2;

					$modal.css({
						top:top + $(window).scrollTop(), 
						left:left + $(window).scrollLeft()
					});
				};

				// Open the modal
				method.open = function (settings) {
					$bar.empty().append(settings.bar);

					$modal.css({
						width: settings.width || 'auto', 
						height: settings.height || 'auto'
					});

					method.center();
					$(window).bind('resize.modal', method.center);
					$modal.show();
					$overlay.show();
				};

				// Close the modal
				method.close = function () {
					$modal.hide();
					$overlay.hide();
					$bar.empty();
					$(window).unbind('resize.modal');
				};

				// Generate the HTML and add it to the document
				$overlay = $('<div id="overlay"></div>');
				$modal = $('<div id="modal"></div>');
				$bar = $('<div id="bar"></div>');
				$close = $('<a id="close" href="#">close</a>');

				$modal.hide();
				$overlay.hide();
				$modal.append($bar, $close);

				$(document).ready(function(){
					$('body').append($overlay, $modal);						
				});

				$close.click(function(e){
					e.preventDefault();
					method.close();
				});

				return method;
			}());
      
     $( document ).ready(function() {
       $("#saveFac").hide();
       if($('#facility_id').length > 0) {
         $('#editFacility').show();
         $("#addFacility").hide();
         $('#facility_name').attr('disabled','disabled');
         $('#wz_name').focus();
       }

      if($('#FC1').val()=='x') {
             updateWZ();
             $("#editZone").hide();
	}
      if($('#FC2').val()=='x') {
             updateAR();
             $('#saverack').attr('disabled','disabled');
	}
      if($('#FC3').val()=='x') {
             updateAR();
             $('.barcode').hide();
             $('#printrow').attr('disabled','disabled');
             $('#saverow').attr('disabled','disabled');
             $('#deleterow').attr('disabled','disabled');
	}
      if($('#FC4').val()=='x') {
             updateAR();
	}
      $(function() {
         $('#dob').datepicker();
      });
    });
    function editFac() {
         $('#saveFac').show();
         $("#editFac").hide();
         $('#facility_name').removeAttr('disabled');
         $('#facility_name').focus();
    }
    function saveFac() {
         $('#saveFac').hide();
         $("#editFac").show();
         $('#facility_name').attr('disabled','disabled');
         $('#wz_name').focus();
       $.post(url,{facility_id:$("#facility_id").val(),facility_name:$("#facility_name").val(),action:"editFac"});
    }
    function saveRow() {
       $('#R'+$("#row_id").val()).css({'background-color':'#FFF'});
       $.post(url,{id:$("#row_id").val(),valves:$("#number_valves").val(),action:"saveRow"});

       loadRack( $('#rackid').val());
    }
    function closer() {
 	 window.location =  '/page.php/configure-tanks';
     }
    function addFacility() {
        $.post(url,{facility_name:$("#facility_name").val(),action:"addFac"},
           function(response){
           $('#wz_name').focus();
           alert(response);
           $('#facility_id').val(response);
         });
        $("#addFacility").hide();
        $("#editFacility").show();
        $('#facility_name').attr('disabled','disabled');
        $('#wz_name').focus();
 
    }
    function addZone() {

        $.post(url,{
        facility_id:$('#facility_id').val(),
        wz_name:$("#wz_name").val(),
        wzowner:$("#wzowner").val(),
        action:"addWZ"},
         function(data){
           updateWZ();
         });
    }
    function addRow() {

        $.post(url,{
        id:$("#rackid").val(),
        valves:$("#number_valves").val(),
        action:"addRow"},
         function(data){
            loadRack($("#rackid").val());
         });
    }
    function writeRack() {
        var ID = $('#rackid').val();
        $.post(url,{
        rack_id:$('#rackid').val(),
        rack_name:$("#rack_name").val(),
        order_rows:$("#order_rows").val(),
        rack_width:$("#rack_width").val(),
        rows:$("#rows").val(),
        action:"PR"},
         function(data){
           updateAR();
           $('#rack_name').val('');
           $('#'+ID).css({'background-color':'#FFF'});
         });
    }
    function setRow(ID) {
            $("#row_id").val(ID);
            $('.Row').css({'background-color':'#FFF'});
            $('#R'+ID).css({'background-color':'yellow'});
            $('#printrow').removeAttr('disabled');
            $('#saverow').removeAttr('disabled');
            $('#deleterow').removeAttr('disabled');
    }
    function addAisle() {

        $.post(url,{
        wz_id:$("#water_zone").val(),
        racks:$("#racks").val(),
        action:"addAisle"},
         function(data){
           updateAR();
         });
    }
   function postFac() {

        $.post(url,{
        fname:$("#facility_name").val(),
        action:"editFac"});
    }
    function editRack(ID) {

        $.post(url,{
        rack_id:ID,
        action:"GR"})
       .done(function(data) {
            $("#rackid").val(ID);
            $("#rack_name").val(data);
            $('#rack_name').focus();
            $('#saverack').removeAttr('disabled');
            $('.rcell').css({'background-color':'#FFF'});
            $('#'+ID).css({'background-color':'yellow'});

         if($('#FC3').val()=='x') {
            loadRack(ID);
	    $('.barcode').show();
	  }
         if($('#FC4').val()=='x') {
            loadRack(ID);
	  }
        });
    }
   function loadRack(ID) {
      $.get( url, {action: "getRows", id: ID} )
       .done(function(html) {
            $("#RoxBox").html(html);
        });
    }
    function updateWZ() {
      $.get( url, {action: "getWZ", id: $('#facility_id').val()} )
       .done(function(html) {
            $("#WZ").html(html);
        });
    }
    function updateAR() {
      $.get( url, {action: "getAR", wz_id: $('#water_zone').val()} )
       .done(function(html) {
            $("#WZA").html(html);
        });
    }

    function getRows() {
      $.get( url, {action: "getRows", rack_id: $('#rackid').val()} )
       .done(function(html) {
            $("#RoxBox").html(html);
            $('.barcode').show();
        });
    }
   function editWZ(ID) {
      $.post(url,{
        id:ID,
        action:"GWZ"})
       .done(function(data) {
           
            $("#rackid").val(ID);
            $("#wz_name").val(data['wz_name']);
            $('#wz_name').focus();
       });
      
      $('#wzid').val(ID);
      $("#saveZone").hide();
      $("#editZone").show();
     }
   function editZone() {
        $.post(url,{
        wz_id:$("#wzid").val(),
        wz_name:$("#wz_name").val(),
        wzowner:$("#wzowner").val(),
        action:"PWZ"})
   .done(function(response)
         { }
       );
      $('#wzid').val('');
      $('#wz_name').focus();
      $('#wz_name').val('');
      $("#saveZone").show();
      $("#editZone").hide();
     }
  function delWZ(ID) {
     var rep = confirm("Delete Water Zone?");
     if (rep == true) {
      $.post( url, { action: "DWZ", id: ID } );
      updateWZ();
     }
   }
  function deleterack() {
     var rep = confirm("Delete Rack?");
     if (rep == true) {
      $.post( url, { action: "DR", rackid: $('#rackid').val() } );
      updateAR();
      $('#rack_name').val('');
     }
   }
  function deleteRow() {
     var rep = confirm("Delete Row?");
     if (rep == true) {
      $.post( url, { action: "DRow", id: $('#row_id').val() } );
      loadRack( $('#rackid').val());
     }
   }
   function printSingle() {
       $.get( url, {action: "printRow", id: $('#row_id').val()} )
       .done(function(data) {
            modal.open({bar: data});
            $('#bar').printElement();
        })
   }
   function printAll() {
       $.get( url, {action: "printAll", row_id: $('#row_id').val()} )
       .done(function(html) {
            $("#bar").html(html);
        })
   }
   function pageOne()
    {
     window.location.assign("http://aquacensus.hopto.org/page.php/configure-layout-racks")
    }
   function pageTwo()
    {
     window.location.assign("http://aquacensus.hopto.org/page.php/new-facility-2")
    }
    function pageThree()
    {
     window.location.assign("http://aquacensus.hopto.org/page.php/new-facility-3")
    }
