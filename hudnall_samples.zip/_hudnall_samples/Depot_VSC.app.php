<?php
	/**
	* Depot VSC
	*
	* The Vendor/Subtractor controller.
	*
	* @package    App
	* @subpackage Controller
	* @author     James Hudnall
	*/
	/*
	*    Put modification notes here (this is not used by phpDocumentor)
	*    1.00.0000 (10/01/2013) [JDH] Original
	*/
	class app_controller_DepotVSC extends Controller_ControllerAbstract
	{
		/**
		 * Requests Object
		 * 
		 * @var Interface_IRequests
		 */
		private $_objRequests;
		
		/**
		 * View Object
		 * 
		 * @var app_view_AdminGroups
		 */
		private $_objView;
		
		/**
		 * Admin Common View Object
		 * 
		 * @var app_view_AdminCommon
		 */
		private $_objViewCommon;
		
		/**
		 * Model Object
		 * 
		 * @var app_model_AdminGroups
		 */
		private $_objModel;
		
		/**
		 * User ID
		 * 
		 * @var integer
		 */
		private $_UserID;
		
		/**
		 * Read Only
		 * 
		 * @var boolean
		 */
		private $_ReadOnly;
		
		/**
		 * User Message
		 * 
		 * @var string
		 */
		private $_UserMessage;
		
		/**
		 * Constructor 
		 * 
		 * @param Interface_IRequests $objRequests
		 * @param integer $UserID
		 * @param boolean $ReadOnly
		 */
		function __construct(Interface_IRequests $objRequests, $UserID, $ReadOnly)
		{
			
			//Set Request
			$this->_objRequests = $objRequests;
			
			//Set User ID
			$this->_UserID = $UserID;
			
			//Set Read Only
			$this->_ReadOnly = $ReadOnly;
			
			//Load Model
			$this->_objModel = $this->loadModel('app_model_DepotVSC');
			
			//Load Views
			$this->_objView = $this->loadView('app_view_DepotVSC');
			$this->_objViewCommon = $this->loadView('app_view_AdminCommon');
			
			//Init user message
			$this->_UserMessage = '';
			
			//Get Action, if any
			$action = $objRequests->getAction();
			
			//If there is an action but read only is true then redirect browser to read only view
			if ($ReadOnly and !empty($action)){
				$this->redirectBrowser('ReadOnly');
			}
			
			//Handle actions
			switch ($action){
				case 'Add':
					$this->_UserMessage = $this->actionAdd();
					break;
				case 'Edit':
					$this->_UserMessage = $this->actionEdit();
					break;
				case 'Delete':
					$this->_UserMessage = $this->actionDelete();
					break;
				case 'AddPart':
					$this->actionAddPart();
				default:
					//No action
			}
			
			//Handle sub request and call controller function accordingly.
			$subRequest = $objRequests->getOption(0);
			switch ($subRequest){
				case 'Add':
					$this->showAddView();
					break;
				case 'Edit':
					$this->showEditView();
					break;
				case 'Delete':
					$this->showDeleteView();
					break;
				case 'Locked':
					$this->_UserMessage = LANGUAGE_ADMIN_GROUPS_LOCKED;
					$this->showDefaultView();
					break;
				default:
					$this->showDefaultView();
			}
		}
			
		/**
		 * Show Default View
		 */
		private function showDefaultView()
		{
			//Set Request URI
			$request = $this->_objRequests->getRequest();
			$requestedURI = MVC_ROOT_URL . '/' . $request;
			//debug_add_string($requestedURI, 'Request URI');
			
			$requestInvType = $this->_objRequests->getRequest();
			
			//Set Cancel URI
			$cancelURI = MVC_ROOT_URL . '/AdminHome';
			
			//Screen Title
			$screenTitle = LMIS_LANGUAGE_ADMIN_VSC_SCREEN_TITLE;
			
			//Get Fields
			$fieldsArray = $this->_objModel->getGridFieldsArray();
			
			//Get Titles
			$titlesArray = $this->_objModel->getGridTitlesArray();
			
			//Get Data
			$dataArray = $this->_objModel->getAllData();
			
			//Get Click ID Field
			$ClickIDfield = 'VSC_ID';
			
			//Get Buttons
			$topButtonCaptionsArray = $this->_objModel->getTopButtonCaptionsArray();
			$topButtonURIarray = $this->_objModel->getTopButtonURIsArray($request);
			$topButtonAppendTextArray = $this->_objModel->getTopButtonAppendTextArray();
			
			//Display View
			$this->_objViewCommon->viewGrid(
				$requestedURI, 
				$screenTitle, 
				$this->_UserMessage, 
				$fieldsArray, 
				$titlesArray, 
				$dataArray, 
				$ClickIDfield, 
				$topButtonCaptionsArray, 
				$topButtonURIarray, 
				$topButtonAppendTextArray
			);
			
		}
			
		/**
		 * Show Add View
		 */
		private function showAddView()
		{
			//Set Request URI
			$request = $this->_objRequests->getRequest();
			$subRequest = $this->_objRequests->getOption(0);
			$requestedURI = MVC_ROOT_URL . '/' . $request . '/' . $subRequest;
			//debug_add_string($requestedURI, 'Request URI');
			
			$requestInvType = $this->_objRequests->getRequest();
			$types = $this->_objModel->getTypes();
			//Set Cancel URI
			$cancelURI = MVC_ROOT_URL . '/' . $request;
			
			//Screen Title
			$screenTitle = LMIS_LANGUAGE_ADMIN_VSC_SCREEN_TITLE . ' - ' . LANGUAGE_COMMON_TITLE_ADD;
			
			//Get Post Data
			if ($this->_objRequests->getAction() == 'Add'){
				$PostData = $this->_objRequests->getDataArray();
			} else {
				$PostData = $this->_objModel->getPostDataAdd();
			}
			
			$this->_objView->viewAddVSC(
				$requestedURI, 
				$screenTitle, 
				$this->_UserMessage, 
				$cancelURI,
				$permission,
				$permissionsArray, 
				$PostData,
				$types
			);			
		}
		
		/**
		 * Show Edit View
		 */
		private function showEditView()
		{
			//Set Request URI
			$request = $this->_objRequests->getRequest();
			$subRequest = $this->_objRequests->getOption(0);
			$VSCID = $this->_objRequests->getOption(1);
			$requestedURI = MVC_ROOT_URL . '/' . $request . '/' . $subRequest . '/' . $VSCID;
			$types = $this->_objModel->getTypes();
			
			//debug_add_string($requestedURI, 'Request URI');
			
			$requestInvType = $this->_objRequests->getRequest();
			
			//Set Cancel URI
			$cancelURI = MVC_ROOT_URL . '/' . $request;
			
			//Screen Title
			$screenTitle = LMIS_LANGUAGE_ADMIN_VSC_SCREEN_TITLE . ' - ' . LANGUAGE_COMMON_TITLE_EDIT;
			
			$partlist = $this->_objModel->getPartList($VSCID);
			
			//Get Post Data
			if ($this->_objRequests->getAction() == 'Edit'){
				$PostData = $this->_objRequests->getDataArray();
			} else {
				$PostData = $this->_objModel->getPostDataEdit($VSCID);
			}
			
			$this->_objView->viewEditVSC(
				$requestedURI, 
				$screenTitle, 
				$this->_UserMessage, 
				$cancelURI,
				$partlist, 
				$PostData,
				$types
			);	
		}
		
		/**
		 * Show Delete View
		 */
		private function showDeleteView()
		{
			//Set Request URI
			$request = $this->_objRequests->getRequest();
			$subRequest = $this->_objRequests->getOption(0);
			$VSCID = intval($this->_objRequests->getOption(1));
			$requestedURI = MVC_ROOT_URL . '/' . $request . '/' . $subRequest . '/' . $VSCID;
			$VSCName = $this->_objModel->getVSCName($VSCID);

			
			//Set Cancel URI
			$cancelURI = MVC_ROOT_URL . '/' . $request;
			
			//Screen Title
			$screenTitle = LMIS_LANGUAGE_ADMIN_VSC_SCREEN_TITLE . ' - ' . LANGUAGE_COMMON_TITLE_DELETE;
			
			//Display View
			$this->_objViewCommon->deleteView(
				$requestedURI, 
				$cancelURI, 
				$this->_UserMessage, 
				$screenTitle, 
				LANGUAGE_ADMIN_VSC_DELETE_MESSAGE, 
				'Delete',
				$VSCName
			);
		}
		
		/**
		 * Action Add
		 */
		private function actionAdd()
		{
			//Add Group
			$ErrorMessage = $this->_objModel->addVSC($this->_objRequests->getDataArray());
			
			//Get Success Request
			$SuccessRequest = $this->_objRequests->getRequest();
			
			//Return Result if error else redirect to inventory if successful
			if ($ErrorMessage === true){
				//Success
				$this->redirectBrowser($SuccessRequest);
			} else {
				//Fail
				return $ErrorMessage;
			}
		}
		
		/**
		 * Action Edit
		 */
		private function actionEdit()
		{
			//Edit Group
			$ErrorMessage = $this->_objModel->editVSC($this->_objRequests->getDataArray());
			
			//Get Success Request
			$SuccessRequest = $this->_objRequests->getRequest();
			
			//Return Result if error else redirect to inventory if successful
			if ($ErrorMessage === true){
				//Success
				$this->redirectBrowser($SuccessRequest);
			} else {
				//Fail
				return $ErrorMessage;
			}
		}
		
		/**
		 * Action Delete
		 */
		private function actionDelete()
		{
			//Delete Group
			$VSCID = intval($this->_objRequests->getOption(1));
			$ErrorMessage = $this->_objModel->deleteVSC($VSCID);
			
			//Get Success Request
			$SuccessRequest = $this->_objRequests->getRequest();
			
			//Return Result if error else redirect to inventory if successful
			if ($ErrorMessage === true){
				//Success
				$this->redirectBrowser($SuccessRequest);
			} else {
				//Fail
				return $ErrorMessage;
			}	
		}
		/**
		 * actionAddPart
		 * 
		 * Add Part Number
		 */
		private function actionAddPart()
		{
			$postArray = $this->_objRequests->getDataArray();

			$ErrorMessage = $this->_objModel->addPart($postArray['Part_Number'], $postArray['VSC_ID']);
			//Get Success Request
			$SuccessRequest = $this->_objRequests->getRequest();
			$SuccessRequest .= '/Edit/' . $postArray['VSC_ID'];
			$ErrorRequest = $SuccessRequest.'/1';
			//Redirect on success or display error on same view.
			if ($ErrorMessage === true){
				//Success
				$this->redirectBrowser($SuccessRequest);
			} else {
				//Fail
				$this->redirectBrowser($ErrorRequest);
			}
		}
		/**
		 * Action Delete Part Number
		 *
		 * @param integer $DesID
		 */
		private function actionDeletePart($DesID)
		{
			$ID = $this->_objRequests->getOption(3);
			$ErrorMessage = $this->_objModel->deleteRecord($ID, 'Part');
		
			//Get Success Request
			$SuccessRequest = $this->_objRequests->getRequest();
			$SuccessRequest .= '/EditDescriptors/'.$DesID;
		
			//Redirect on success or display error on same view.
			if ($ErrorMessage === true){
				//Success
				$this->redirectBrowser($SuccessRequest);
			} else {
				//Fail
				return $ErrorMessage;
			}
		}
	}