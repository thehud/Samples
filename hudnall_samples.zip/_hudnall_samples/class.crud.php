<?php
/**
*  CRUD class sample code using PDO
*  Author: James Hudnall (james.hudnall@gmail.com)
*
**/
class crud
{

    private $db;

    /**
     *
     * Set variables  (values passed via constants from separate file to this method)
     *
     */
    public function __set($name, $value)
    {
        switch($name)
        {
            case 'username':
            $this->username = $value;
            break;

            case 'password':
            $this->password = $value;
            break;

            case 'dsn':
            $this->dsn = $value;
            break;

            default:
            throw new Exception("$name is invalid");
        }
    }

    /**
     *
     * @check variables have default value
     *
     */
    public function __isset($name)
    {
        switch($name)
        {
            case 'username':
            $this->username = null;
            break;

            case 'password':
            $this->password = null;
            break;
        }
    }

        /**
         *
         * @Connect to the database and set the error mode to Exception
         *
         * @Throws PDOException on failure
         *
         */
        public function conn()
        {
            isset($this->username);
            isset($this->password);
            if (!$this->db instanceof PDO)
            {
                $this->db = new PDO($this->dsn, $this->username, $this->password);
                $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
        }


        /***
         *
         * @select values from table
         *
         * @access public
         *
         * @param string $table The name of the table
         *
         * @param string $fieldname
         *
         * @param string $id
         *
         * @return array on success or throw PDOException on failure
         *
         */
        public function dbSelect($table, $fieldname=null, $id=null)
        {
            $table = self::clean_variable($table);
            $fieldname = self::clean_variable($fieldname);
            $this->conn();
            $sql = "SELECT * FROM `$table` WHERE `$fieldname`=:id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }


        /**
         *
         * @execute a raw query
         *
         * @access public
         *
         * @param string $sql
         *
         * @return array
         *
         */
        public function rawSelect($sql)
        {
            $sql = self::clean_variable($sql);
            $this->conn();
            return $this->db->query($sql);
        }

        /**
         *
         * @run a raw query
         *
         * @param string The query to run
         *
         */
        public function rawQuery($sql)
        {
            $sql = self::clean_variable($sql);
            $this->conn();
            $this->db->query($sql);
        }


        /**
         *
         * @Insert a value into a table
         *
         * @acces public
         *
         * @param string $table
         *
         * @param array $values
         *
         * @return int The last Insert Id on success or throw PDOexeption on failure
         *
         */
        public function dbInsert($table, $values)
        {
            $table = self::clean_variable($table);
            $values = self::clean_variable($values);
            $this->conn();
            /*** snarg the field names from the first array member ***/
            $fieldnames = array_keys($values[0]);
            /*** now build the query ***/
            $size = sizeof($fieldnames);
            $i = 1;
            $sql = "INSERT INTO $table";
            /*** set the field names ***/
            $fields = '( ' . implode(' ,', $fieldnames) . ' )';
            /*** set the placeholders ***/
            $bound = '(:' . implode(', :', $fieldnames) . ' )';
            /*** put the query together ***/
            $sql .= $fields.' VALUES '.$bound;

            /*** prepare and execute ***/
            $stmt = $this->db->prepare($sql);
            foreach($values as $vals)
            {
                $stmt->execute($vals);
            }
        }

        /**
         *
         * @Update a row in a table based on primary key value
         *
         * @access public
         * @param string $table
         * @param array $columns     columns to be set
         * @param array $values      values to be set
         * @param string $pk The primary key
         * @param string $id The id
         * @throws PDOException on failure
         *
         */
        public function dbUpdate($table, $columns, $values, $pk, $id)
        {
          // Clean $table, array $values
			$table = self::clean_variable($table);

			foreach ($columns as &$column)
			{
				$column = self::clean_variable($column);
			}

			foreach ($values as &$value)
			{
				$value = self::clean_variable($value);
			}
            $pk = self::clean_variable($pk);
            $id = self::clean_variable($id);
           // Build the query string
			// Concatenate the set string
			if (is_null($values[0])){
				$set = "`{$columns[0]}` = NULL";
			} else {
				$set = "`{$columns[0]}` = '{$values[0]}'";
			}
			for ($x = 1; $x < count($columns); $x++)
			{
				if (is_null($values[$x])){
					$set .=  ", `{$columns[$x]}` = NULL";
				} else {
					$set .=  ", `{$columns[$x]}` = '{$values[$x]}'";
				}
			}

			// Concatenate the where conditions
			$where = ' ';

			// Set update string depending on requested fields and conditions
			if (empty($pk)){
				$where = '';
			} else {
				$where = "WHERE `$pk` = :id";
			}
			// Execute the update
				$sql = "
					UPDATE
					`$table`
					SET $set
					$where
			  	";
            // process update
            $this->conn();
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_STR);
            $stmt->execute();
        }


        /**
         *
         * @Delete a record from a table
         *
         * @access public
         *
         * @param string $table
         *
         * @param string $fieldname
         *
         * @param string $id
         *
         * @throws PDOexception on failure
         *
         */
        public function dbDelete($table, $fieldname, $id)
        {
            $table = self::clean_variable($table);
            $fieldname = self::clean_variable($fieldname);
            $this->conn();
            $sql = "DELETE FROM `$table` WHERE `$fieldname` = :id";

            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':id', $id, PDO::PARAM_STR);
            $stmt->execute();
        }

                /**
         *
         * @Create a select statement content  from a standard array of key->value
         *
         * @access public
         * @param array $data
         * @param string $id
         * @param string $value
         * @return array $drop
         *
         */
        public function dropDown($data, $id)
        {
            foreach($data as $D)
            {
            $drop[] = '<option value="' . $D[$id] .'">'.$D[$value].'</option>';
            };
            return $drop
        }
        /**
         *
         * @Creates a drop down options list from a selected grouping
         *
         * @access public
         * @param string $table
         * @param string $fieldname
         * @param string $id
         * @throws PDOexception on failure
         *
         */
        public function getDDSelect($table, $id,$field,$group,$value)
        {
            $dd = '';
            $this->conn();
            $sql = "SELECT $id, $field FROM `$table` WHERE $group  = '$value'";
            $rs = $this->db->query($sql);
            $row = $rs->fetchAll(PDO::FETCH_ASSOC);
            foreach ($row as $R) {
                  $dd .= '<option value="' . $R[$id] . '">' . $R[$field] . '</option>';
            }
           return $dd;
        }
        /**
		* Cleans variable via Security class  (not included in sample)
		*
		* @param mixed $source
		* @param boolean $allowPercent Allow % to remain
		* @param boolean $binarySafe
		* @return mixed $cleaned
		*/
		protected static function clean_variable($source, $allowPercent=false, $binarySafe = false)
		{
			//Resuse security object if already set instead of creating another.
			if (!isset($reg_security)){
				$reg_security = new Security();
			}
			$reg_security->setInput($source);
			$reg_security->actionEscape($allowPercent, $binarySafe);
			$cleaned=$reg_security->getOutput();
			return $cleaned;
		}
    } /*** end of class ***/

?>